import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type UserRole = 'admin' | 'inventory_manager' | 'sales_staff';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  avatar?: string;
}

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  setUser: (user: User) => void;
  hasPermission: (permission: string) => boolean;
}

// Role permissions mapping
const rolePermissions: Record<UserRole, string[]> = {
  admin: ['all'],
  inventory_manager: [
    'products.view',
    'products.create',
    'products.edit',
    'products.delete',
    'stock.view',
    'stock.manage',
    'warehouses.view',
    'warehouses.manage',
    'purchases.view',
    'purchases.create',
    'reports.view',
    'ai.view',
    'ai.suggestions',
  ],
  sales_staff: [
    'products.view',
    'sales.view',
    'sales.create',
    'reports.view-limited',
  ],
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      isAuthenticated: false,

      login: async (email: string, password: string) => {
        // Mock login - in production, this would call the API
        await new Promise((resolve) => setTimeout(resolve, 1000));

        // Mock user data based on email
        let mockUser: User;
        if (email.includes('admin')) {
          mockUser = {
            id: '1',
            email,
            name: 'Admin User',
            role: 'admin',
            avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=admin',
          };
        } else if (email.includes('manager')) {
          mockUser = {
            id: '2',
            email,
            name: 'Inventory Manager',
            role: 'inventory_manager',
            avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=manager',
          };
        } else {
          mockUser = {
            id: '3',
            email,
            name: 'Sales Staff',
            role: 'sales_staff',
            avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sales',
          };
        }

        const mockToken = `mock-jwt-token-${Date.now()}`;

        set({
          user: mockUser,
          token: mockToken,
          isAuthenticated: true,
        });
      },

      logout: () => {
        set({
          user: null,
          token: null,
          isAuthenticated: false,
        });
      },

      setUser: (user: User) => {
        set({ user });
      },

      hasPermission: (permission: string) => {
        const { user } = get();
        if (!user) return false;
        
        const permissions = rolePermissions[user.role];
        return permissions.includes('all') || permissions.includes(permission);
      },
    }),
    {
      name: 'auth-storage',
    }
  )
);
