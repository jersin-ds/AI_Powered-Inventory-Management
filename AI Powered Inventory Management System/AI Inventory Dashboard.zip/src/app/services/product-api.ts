import { mockProducts, type Product } from './mock-data';

// Mock API delay
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export const productApi = {
  getAll: async (): Promise<Product[]> => {
    await delay(500);
    return mockProducts;
  },

  getById: async (id: string): Promise<Product | undefined> => {
    await delay(300);
    return mockProducts.find((p) => p.id === id);
  },

  create: async (product: Omit<Product, 'id' | 'createdAt'>): Promise<Product> => {
    await delay(500);
    const newProduct: Product = {
      ...product,
      id: `${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    mockProducts.push(newProduct);
    return newProduct;
  },

  update: async (id: string, updates: Partial<Product>): Promise<Product> => {
    await delay(500);
    const index = mockProducts.findIndex((p) => p.id === id);
    if (index === -1) throw new Error('Product not found');
    
    mockProducts[index] = { ...mockProducts[index], ...updates };
    return mockProducts[index];
  },

  delete: async (id: string): Promise<void> => {
    await delay(500);
    const index = mockProducts.findIndex((p) => p.id === id);
    if (index === -1) throw new Error('Product not found');
    
    mockProducts.splice(index, 1);
  },

  search: async (query: string): Promise<Product[]> => {
    await delay(400);
    const lowerQuery = query.toLowerCase();
    return mockProducts.filter(
      (p) =>
        p.name.toLowerCase().includes(lowerQuery) ||
        p.sku.toLowerCase().includes(lowerQuery) ||
        p.category.toLowerCase().includes(lowerQuery)
    );
  },
};
