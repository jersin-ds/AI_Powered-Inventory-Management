import { mockAIInsights, type AIInsight } from './mock-data';

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export const aiApi = {
  getInsights: async (): Promise<AIInsight[]> => {
    await delay(600);
    return mockAIInsights;
  },

  getInsightsByType: async (type: AIInsight['type']): Promise<AIInsight[]> => {
    await delay(400);
    return mockAIInsights.filter((insight) => insight.type === type);
  },

  chat: async (message: string, history: ChatMessage[]): Promise<string> => {
    await delay(800);
    
    // Mock AI responses based on keywords
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('stock') || lowerMessage.includes('inventory')) {
      return "Based on current inventory levels, you have 3 items that are out of stock and 15 items with low stock. I recommend prioritizing reorders for Wireless Mouse (15 units remaining) and USB-C Cable (15 units). The AI forecast predicts increased demand for these items in the coming weeks.";
    }
    
    if (lowerMessage.includes('sales') || lowerMessage.includes('revenue')) {
      return "Your sales performance is strong! Total revenue this month is $125,430 with a profit margin of 36%. The top-selling product is Webcam HD with 180 units sold. I notice a 300% spike in webcam sales, which could indicate a market trend. Consider increasing stock levels.";
    }
    
    if (lowerMessage.includes('demand') || lowerMessage.includes('forecast')) {
      return "Demand forecasting shows:\n\n• **Wireless Mouse**: 40% increase expected (recommend ordering 200 units)\n• **Webcam HD**: High demand continuing (maintain 100+ units)\n• **USB-C Cable**: Declining trend (consider promotional pricing)\n\nThe AI model confidence is 87% based on historical data and market trends.";
    }
    
    if (lowerMessage.includes('price') || lowerMessage.includes('pricing')) {
      return "Price optimization analysis suggests:\n\n• **Laptop Stand**: Can support 12% price increase ($35 → $39.20)\n• **USB-C Cable**: Consider 15% discount to move slow inventory\n• **Webcam HD**: Current pricing is optimal given high demand\n\nThese adjustments could increase overall revenue by 8-10%.";
    }
    
    if (lowerMessage.includes('help') || lowerMessage.includes('what can you')) {
      return "I can help you with:\n\n📊 **Inventory Analysis** - Stock levels, reorder recommendations\n📈 **Sales Insights** - Revenue trends, top products\n🔮 **Demand Forecasting** - Predict future demand\n💰 **Price Optimization** - Pricing strategy suggestions\n⚠️ **Alerts** - Low stock, expiry risks, anomalies\n📦 **Product Info** - Details about any product\n\nJust ask me anything about your inventory!";
    }
    
    return "I understand you're asking about inventory management. Could you be more specific? I can help with stock levels, sales analysis, demand forecasting, pricing strategies, or general inventory questions. What would you like to know?";
  },

  getSuggestedPrompts: (): string[] => {
    return [
      "What's my current stock status?",
      "Show me sales performance this month",
      "What items should I reorder?",
      "Analyze demand forecast",
      "Any pricing recommendations?",
      "Which products are slow-moving?",
    ];
  },
};
