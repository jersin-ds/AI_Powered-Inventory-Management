// Mock data for the application

export interface Product {
  id: string;
  sku: string;
  name: string;
  category: string;
  subcategory: string;
  supplier: string;
  costPrice: number;
  sellPrice: number;
  stockQty: number;
  minLevel: number;
  barcode: string;
  image?: string;
  status: 'active' | 'low_stock' | 'out_of_stock';
  createdAt: string;
}

export interface Warehouse {
  id: string;
  name: string;
  location: string;
  capacity: number;
  currentStock: number;
  manager: string;
  status: 'active' | 'inactive';
}

export interface Purchase {
  id: string;
  poNumber: string;
  supplier: string;
  date: string;
  status: 'pending' | 'received' | 'cancelled';
  totalAmount: number;
  items: Array<{
    productId: string;
    productName: string;
    quantity: number;
    price: number;
  }>;
}

export interface Sale {
  id: string;
  invoiceNumber: string;
  customer: string;
  date: string;
  status: 'completed' | 'pending' | 'cancelled';
  totalAmount: number;
  profit: number;
  items: Array<{
    productId: string;
    productName: string;
    quantity: number;
    price: number;
  }>;
}

export interface AIInsight {
  id: string;
  type: 'demand_forecast' | 'dead_stock' | 'anomaly' | 'price_optimization' | 'expiry_risk';
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  actionable: boolean;
  data?: any;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  productCount: number;
  subcategories: string[];
  status: 'active' | 'inactive';
  createdAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  country: string;
  productsSupplied: number;
  totalOrders: number;
  totalValue: number;
  rating: number;
  status: 'active' | 'inactive';
  paymentTerms: string;
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'inventory_manager' | 'sales_staff';
  avatar?: string;
  status: 'active' | 'inactive';
  lastLogin: string;
  createdAt: string;
}

// Mock Products
export const mockProducts: Product[] = [
  {
    id: '1',
    sku: 'SKU001',
    name: 'Wireless Mouse',
    category: 'Electronics',
    subcategory: 'Computer Accessories',
    supplier: 'TechCorp Inc',
    costPrice: 15,
    sellPrice: 25,
    stockQty: 150,
    minLevel: 20,
    barcode: '1234567890123',
    status: 'active',
    createdAt: '2024-01-15',
  },
  {
    id: '2',
    sku: 'SKU002',
    name: 'USB-C Cable',
    category: 'Electronics',
    subcategory: 'Cables',
    supplier: 'CableCo',
    costPrice: 5,
    sellPrice: 12,
    stockQty: 15,
    minLevel: 30,
    barcode: '1234567890124',
    status: 'low_stock',
    createdAt: '2024-01-16',
  },
  {
    id: '3',
    sku: 'SKU003',
    name: 'Mechanical Keyboard',
    category: 'Electronics',
    subcategory: 'Computer Accessories',
    supplier: 'KeyMasters',
    costPrice: 50,
    sellPrice: 85,
    stockQty: 0,
    minLevel: 10,
    barcode: '1234567890125',
    status: 'out_of_stock',
    createdAt: '2024-01-17',
  },
  {
    id: '4',
    sku: 'SKU004',
    name: 'Laptop Stand',
    category: 'Furniture',
    subcategory: 'Desk Accessories',
    supplier: 'ErgoSupply',
    costPrice: 20,
    sellPrice: 35,
    stockQty: 75,
    minLevel: 15,
    barcode: '1234567890126',
    status: 'active',
    createdAt: '2024-01-18',
  },
  {
    id: '5',
    sku: 'SKU005',
    name: 'Webcam HD',
    category: 'Electronics',
    subcategory: 'Computer Accessories',
    supplier: 'TechCorp Inc',
    costPrice: 35,
    sellPrice: 60,
    stockQty: 45,
    minLevel: 10,
    barcode: '1234567890127',
    status: 'active',
    createdAt: '2024-01-19',
  },
];

// Mock Warehouses
export const mockWarehouses: Warehouse[] = [
  {
    id: '1',
    name: 'Main Warehouse',
    location: 'New York, NY',
    capacity: 10000,
    currentStock: 7500,
    manager: 'John Doe',
    status: 'active',
  },
  {
    id: '2',
    name: 'West Coast Hub',
    location: 'Los Angeles, CA',
    capacity: 8000,
    currentStock: 4200,
    manager: 'Jane Smith',
    status: 'active',
  },
  {
    id: '3',
    name: 'Southern Distribution',
    location: 'Houston, TX',
    capacity: 6000,
    currentStock: 3100,
    manager: 'Mike Johnson',
    status: 'active',
  },
];

// Mock Purchases
export const mockPurchases: Purchase[] = [
  {
    id: '1',
    poNumber: 'PO-2024-001',
    supplier: 'TechCorp Inc',
    date: '2024-02-15',
    status: 'received',
    totalAmount: 5000,
    items: [
      { productId: '1', productName: 'Wireless Mouse', quantity: 100, price: 15 },
      { productId: '5', productName: 'Webcam HD', quantity: 50, price: 35 },
    ],
  },
  {
    id: '2',
    poNumber: 'PO-2024-002',
    supplier: 'CableCo',
    date: '2024-02-20',
    status: 'pending',
    totalAmount: 1500,
    items: [
      { productId: '2', productName: 'USB-C Cable', quantity: 300, price: 5 },
    ],
  },
];

// Mock Sales
export const mockSales: Sale[] = [
  {
    id: '1',
    invoiceNumber: 'INV-2024-001',
    customer: 'Acme Corp',
    date: '2024-02-20',
    status: 'completed',
    totalAmount: 1250,
    profit: 500,
    items: [
      { productId: '1', productName: 'Wireless Mouse', quantity: 50, price: 25 },
    ],
  },
  {
    id: '2',
    invoiceNumber: 'INV-2024-002',
    customer: 'Tech Solutions Ltd',
    date: '2024-02-21',
    status: 'completed',
    totalAmount: 3600,
    profit: 1500,
    items: [
      { productId: '5', productName: 'Webcam HD', quantity: 60, price: 60 },
    ],
  },
  {
    id: '3',
    invoiceNumber: 'INV-2024-003',
    customer: 'StartupXYZ',
    date: '2024-02-22',
    status: 'pending',
    totalAmount: 2100,
    profit: 850,
    items: [
      { productId: '4', productName: 'Laptop Stand', quantity: 60, price: 35 },
    ],
  },
];

// Mock AI Insights
export const mockAIInsights: AIInsight[] = [
  {
    id: '1',
    type: 'demand_forecast',
    title: 'High Demand Expected for Wireless Mouse',
    description: 'AI predicts 40% increase in demand for Wireless Mouse over the next 2 weeks. Recommend ordering 200 additional units.',
    priority: 'high',
    actionable: true,
    data: {
      productId: '1',
      predictedDemand: 280,
      currentStock: 150,
      recommendedOrder: 200,
    },
    createdAt: '2024-02-23',
  },
  {
    id: '2',
    type: 'dead_stock',
    title: 'Slow-Moving Item Detected',
    description: 'USB-C Cable has been moving slowly. Only 5 units sold in the last 30 days. Consider 15% discount promotion.',
    priority: 'medium',
    actionable: true,
    data: {
      productId: '2',
      averageMonthlySales: 5,
      currentStock: 15,
      suggestedDiscount: 15,
    },
    createdAt: '2024-02-22',
  },
  {
    id: '3',
    type: 'anomaly',
    title: 'Unusual Sales Pattern',
    description: 'Detected a 300% spike in Webcam HD sales. This could indicate market trend or data anomaly. Review required.',
    priority: 'high',
    actionable: true,
    data: {
      productId: '5',
      normalAverage: 15,
      currentSales: 60,
      percentageChange: 300,
    },
    createdAt: '2024-02-21',
  },
  {
    id: '4',
    type: 'price_optimization',
    title: 'Price Optimization Suggestion',
    description: 'Market analysis suggests Laptop Stand can support 12% price increase without affecting demand.',
    priority: 'low',
    actionable: true,
    data: {
      productId: '4',
      currentPrice: 35,
      suggestedPrice: 39.2,
      expectedRevenue: 1500,
    },
    createdAt: '2024-02-20',
  },
  {
    id: '5',
    type: 'expiry_risk',
    title: 'Stock Nearing Expiry',
    description: 'Batch #B2024-15 of Mechanical Keyboard accessories will expire in 30 days. 25 units at risk.',
    priority: 'medium',
    actionable: true,
    data: {
      productId: '3',
      batchNumber: 'B2024-15',
      expiryDate: '2024-03-25',
      unitsAtRisk: 25,
    },
    createdAt: '2024-02-23',
  },
];

// Mock Dashboard Stats
export const mockDashboardStats = {
  totalRevenue: 125430,
  totalProfit: 45230,
  totalProducts: 1247,
  lowStockItems: 15,
  outOfStockItems: 3,
  pendingOrders: 8,
  revenueGrowth: 12.5,
  profitGrowth: 8.3,
};

// Mock Sales Chart Data
export const mockSalesChartData = [
  { date: '2024-02-01', sales: 3200, profit: 1100 },
  { date: '2024-02-05', sales: 4100, profit: 1450 },
  { date: '2024-02-10', sales: 3800, profit: 1300 },
  { date: '2024-02-15', sales: 5200, profit: 1850 },
  { date: '2024-02-20', sales: 4800, profit: 1700 },
  { date: '2024-02-25', sales: 6100, profit: 2200 },
];

// Mock Revenue by Category
export const mockRevenueByCategory = [
  { category: 'Electronics', value: 65000, percentage: 52 },
  { category: 'Furniture', value: 32000, percentage: 25 },
  { category: 'Office Supplies', value: 18000, percentage: 14 },
  { category: 'Others', value: 10430, percentage: 9 },
];

// Mock Top Products
export const mockTopProducts = [
  { id: '5', name: 'Webcam HD', sales: 180, revenue: 10800 },
  { id: '1', name: 'Wireless Mouse', sales: 150, revenue: 3750 },
  { id: '4', name: 'Laptop Stand', sales: 95, revenue: 3325 },
  { id: '2', name: 'USB-C Cable', sales: 75, revenue: 900 },
  { id: '3', name: 'Mechanical Keyboard', sales: 32, revenue: 2720 },
];

// Mock Categories
export const mockCategories: Category[] = [
  {
    id: '1',
    name: 'Electronics',
    description: 'Electronic devices and accessories',
    productCount: 847,
    subcategories: ['Computer Accessories', 'Cables', 'Audio Equipment', 'Mobile Accessories'],
    status: 'active',
    createdAt: '2023-01-15',
  },
  {
    id: '2',
    name: 'Furniture',
    description: 'Office and home furniture items',
    productCount: 234,
    subcategories: ['Desk Accessories', 'Chairs', 'Storage', 'Tables'],
    status: 'active',
    createdAt: '2023-02-20',
  },
  {
    id: '3',
    name: 'Office Supplies',
    description: 'General office supplies and stationery',
    productCount: 156,
    subcategories: ['Writing Tools', 'Paper Products', 'Organization', 'Printing Supplies'],
    status: 'active',
    createdAt: '2023-03-10',
  },
  {
    id: '4',
    name: 'Others',
    description: 'Miscellaneous items',
    productCount: 10,
    subcategories: ['General'],
    status: 'active',
    createdAt: '2023-04-05',
  },
];

// Mock Suppliers
export const mockSuppliers: Supplier[] = [
  {
    id: '1',
    name: 'TechCorp Inc',
    contactPerson: 'John Smith',
    email: 'john.smith@techcorp.com',
    phone: '+1 (555) 123-4567',
    address: '123 Tech Street',
    city: 'San Francisco',
    country: 'USA',
    productsSupplied: 245,
    totalOrders: 89,
    totalValue: 456780,
    rating: 4.8,
    status: 'active',
    paymentTerms: 'Net 30',
    createdAt: '2022-06-15',
  },
  {
    id: '2',
    name: 'CableCo',
    contactPerson: 'Sarah Johnson',
    email: 'sarah@cableco.com',
    phone: '+1 (555) 234-5678',
    address: '456 Cable Avenue',
    city: 'Austin',
    country: 'USA',
    productsSupplied: 120,
    totalOrders: 45,
    totalValue: 123450,
    rating: 4.5,
    status: 'active',
    paymentTerms: 'Net 45',
    createdAt: '2022-08-20',
  },
  {
    id: '3',
    name: 'KeyMasters',
    contactPerson: 'Michael Chen',
    email: 'michael@keymasters.com',
    phone: '+1 (555) 345-6789',
    address: '789 Keyboard Lane',
    city: 'Seattle',
    country: 'USA',
    productsSupplied: 87,
    totalOrders: 34,
    totalValue: 287900,
    rating: 4.9,
    status: 'active',
    paymentTerms: 'Net 30',
    createdAt: '2022-09-10',
  },
  {
    id: '4',
    name: 'ErgoSupply',
    contactPerson: 'Emily Davis',
    email: 'emily@ergosupply.com',
    phone: '+1 (555) 456-7890',
    address: '321 Ergo Road',
    city: 'Portland',
    country: 'USA',
    productsSupplied: 156,
    totalOrders: 67,
    totalValue: 345670,
    rating: 4.7,
    status: 'active',
    paymentTerms: 'Net 30',
    createdAt: '2022-10-05',
  },
  {
    id: '5',
    name: 'Global Tech Supplies',
    contactPerson: 'David Brown',
    email: 'david@globaltech.com',
    phone: '+1 (555) 567-8901',
    address: '654 Global Plaza',
    city: 'New York',
    country: 'USA',
    productsSupplied: 312,
    totalOrders: 102,
    totalValue: 678920,
    rating: 4.6,
    status: 'active',
    paymentTerms: 'Net 60',
    createdAt: '2022-07-12',
  },
];

// Mock Users
export const mockUsers: User[] = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@inventory.com',
    role: 'admin',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=admin',
    status: 'active',
    lastLogin: '2024-02-25T10:30:00Z',
    createdAt: '2022-01-01',
  },
  {
    id: '2',
    name: 'John Manager',
    email: 'manager@inventory.com',
    role: 'inventory_manager',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=manager1',
    status: 'active',
    lastLogin: '2024-02-25T09:15:00Z',
    createdAt: '2022-03-15',
  },
  {
    id: '3',
    name: 'Sarah Sales',
    email: 'sales@inventory.com',
    role: 'sales_staff',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sales1',
    status: 'active',
    lastLogin: '2024-02-25T08:45:00Z',
    createdAt: '2022-05-20',
  },
  {
    id: '4',
    name: 'Emily Manager',
    email: 'emily.manager@inventory.com',
    role: 'inventory_manager',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=manager2',
    status: 'active',
    lastLogin: '2024-02-24T16:30:00Z',
    createdAt: '2022-06-10',
  },
  {
    id: '5',
    name: 'Mike Sales',
    email: 'mike.sales@inventory.com',
    role: 'sales_staff',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sales2',
    status: 'active',
    lastLogin: '2024-02-24T14:20:00Z',
    createdAt: '2022-08-05',
  },
  {
    id: '6',
    name: 'Jessica Staff',
    email: 'jessica@inventory.com',
    role: 'sales_staff',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sales3',
    status: 'inactive',
    lastLogin: '2024-02-15T11:00:00Z',
    createdAt: '2023-01-12',
  },
];