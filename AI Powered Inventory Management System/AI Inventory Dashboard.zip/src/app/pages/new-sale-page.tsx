import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { DollarSign } from 'lucide-react';

export function NewSalePage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold flex items-center gap-2">
        <DollarSign className="h-8 w-8" />
        New Sale
      </h1>
      <Card className="glass">
        <CardHeader>
          <CardTitle>Create Sale</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Sale creation form coming soon...</p>
        </CardContent>
      </Card>
    </div>
  );
}
