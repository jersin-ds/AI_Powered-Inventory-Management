import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { ShoppingCart } from 'lucide-react';

export function NewPurchasePage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold flex items-center gap-2">
        <ShoppingCart className="h-8 w-8" />
        New Purchase Order
      </h1>
      <Card className="glass">
        <CardHeader>
          <CardTitle>Create Purchase Order</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Purchase order creation form coming soon...</p>
        </CardContent>
      </Card>
    </div>
  );
}
