import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Warehouse } from 'lucide-react';
import { mockWarehouses } from '../services/mock-data';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';

export function WarehousesPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Warehouse className="h-8 w-8" />
          Warehouses
        </h1>
        <p className="text-muted-foreground mt-1">Manage warehouse locations and stock</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {mockWarehouses.map((warehouse) => {
          const utilization = (warehouse.currentStock / warehouse.capacity) * 100;
          return (
            <Card key={warehouse.id} className="glass card-hover">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>{warehouse.name}</CardTitle>
                  <Badge className={warehouse.status === 'active' ? 'bg-green-500' : 'bg-gray-500'}>
                    {warehouse.status}
                  </Badge>
                </div>
                <CardDescription>{warehouse.location}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-muted-foreground">Capacity Utilization</span>
                    <span className="font-medium">{utilization.toFixed(0)}%</span>
                  </div>
                  <Progress value={utilization} className="h-2" />
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Current Stock</p>
                    <p className="font-bold text-lg">{warehouse.currentStock.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Capacity</p>
                    <p className="font-bold text-lg">{warehouse.capacity.toLocaleString()}</p>
                  </div>
                </div>
                <div>
                  <p className="text-muted-foreground text-sm">Manager</p>
                  <p className="font-medium">{warehouse.manager}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
